<?php

	$message = "Application has been approved";
	echo "<script type='text/javascript'>alert('$message');
	window.location.href = 'home.php';
	</script>";

?>
